//timer_fresh
#include "atmel_start.h"
#include <hal_gpio.h>
#include <hal_delay.h>  
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


//****************************************** Kinematics code 
#define driver_res 1 

#define N_Axis 5
#define steps_per_mm 800
#define steps_per_radian 127
#define motion_buffer_size 256
#define total_num_blocks 6
#ifndef max
    #define max(a,b) (a>b ? a:b)
#endif
#ifndef M_PI
	#define M_PI 3.141592654
#endif  

//typedef struct{
    //uint32_t steps[N_Axis]; 
    //uint32_t step_count;
    //float start_speed;
    //float max_start_speed;
    //float flat_speed;
    //float acceleration;
    //float millimeters;
    //float radians;
//}motion_block_t; 
//static motion_block_t motion_buffer[motion_buffer_size]; 
volatile int motion_buffer_head;
typedef struct{
    uint32_t position[N_Axis];
    float direction[N_Axis];
    float prev_speed;
} pos_info_t;
static pos_info_t pos;    
void delay();
double *inv_kin_slow();
void update_motion_buffer();


//****************************************** Kinematics code  


static struct timer_task task0, task1, task2; 

volatile int x_counter = 0; 
volatile int x_stepper = 0; 

volatile int y_counter = 0; 
volatile int y_stepper = 0; 

volatile int z_counter = 0; 
volatile int z_stepper = 0; 

volatile int a_counter = 0; 
volatile int a_stepper = 0; 

volatile int c_counter = 0; 
volatile int c_stepper = 0; 


volatile int x_tog = 0; 
volatile int y_tog = 0; 

volatile int x_dir = 0;
volatile int y_dir = 0;
volatile int z_dir = 0;

volatile int a_dir = 0;
volatile int c_dir = 0;

volatile int x_enable = 0;
volatile int y_enable = 0;
volatile int z_enable = 0;  

volatile int x_dir_enable = 0;
volatile int y_dir_enable = 0;
volatile int z_dir_enable = 0;

volatile int  xglob_cout;
volatile int  yglob_cout;
volatile int  zglob_cout;

volatile int index = 0; 
volatile int num_com = 0; 
volatile int bh_enable = 0; 

volatile int ramp_counter = 0; 
volatile int enable_high = 0; 
volatile int enable_low = 0;  

volatile int period = 200; 

static void task0_cb(const struct timer_task *const timer_task) 
{                 
  if (x_enable == 1){  
    x_enable = 0; 
  }  
  if (y_enable == 1){ 
    y_enable = 0;
  }  
  if (z_enable == 1){ 
    z_enable = 0;
  }     
}  
volatile  int axis_selector = 0;  
volatile  int block_index = 0; 

void plotLine (int x0, int y0, int x1, int y1); 

typedef struct{
    uint32_t steps[N_Axis];   
    uint32_t step_sequence[100000]; 
    uint32_t global_counter;
    uint32_t direction[N_Axis];   
}motion_block_t;

static motion_block_t motion_buffer[motion_buffer_size]; //array of motion buffer structures  


int main(void)
{ 
  atmel_start_init();  
      delay_ms(1000);
      task0.interval = 10; 
      task0.cb = task0_cb; 
      task0.mode = TIMER_TASK_REPEAT;  
      timer_add_task(&TIMER_0, &task0);      
      timer_start(&TIMER_0);   
      //****************************************** Kinematics code  
      volatile double input_stream[total_num_blocks][3] = 
        { 
         {1,0,0}, 
         {0,1,0},
         {0,0,1},
         {5,2,7},
         {1,2,3},
         {6,8,4},
        };    
      //****************************************** Kinematics code      
   volatile int incrementor = 0;
 for (int y = 0; y < total_num_blocks; y ++) {     
   int holder = 0;

   //x_counter = abs(motion_buffer[y].steps[0]); //taking absolute I don't want to deal with negative for know
   //y_counter = abs(motion_buffer[y].steps[1]);
   //z_counter = abs(motion_buffer[y].steps[2]); 
   x_counter = (input_stream[y][0])*100; 
   y_counter = (input_stream[y][1])*100;   
   z_counter = (input_stream[y][2])*100;     

   if (x_counter < 0) //if the steps is negative it means a negative direction
   { 
     x_dir = 0; //setting direction pin to low
   }  
   else 
   { 
     x_dir = 1; //else if positive  num, then set high
   } 

   if (y_counter < 0) //if the steps is negative it means a negative direction
   { 
     y_dir = 0; //setting direction pin to low
   }  
   else 
   { 
     y_dir = 1; //else if positive  num, then set high
   }
   if (z_counter < 0) //if the steps is negative it means a negative direction
   { 
     z_dir = 0; //setting direction pin to low
   }  
   else 
   { 
     z_dir = 1; //else if positive  num, then set high
   } 

  int dx, dy, dz, xs, ys, zs, p1, p2;  
  int x1 = 0; 
  int y1 = 0; 
  int z1 = 0; 
  int x2 = x_counter;
  int y2 = y_counter;
  int z2 = z_counter; 

  dx =  abs(x2-x1);
  dy =  abs(y2-y1);
  dz =  abs(z2-z1);  

  if  (x2 > x1){  
    xs = 1;
  }else{ 
    xs = -1;
  }
  if  (y2 > y1){  
    ys = 1;
  }else{ 
    ys = -1;
  }
  if  (z2 > z1){  
    zs = 1;
  }else{ 
    zs = -1;
  }     
  // Driving the xaxis 
  if (dx >= dy && dx >= dz) 
  { 
    /* x2 - x1 is greater than both y2 - y1 and z2 - z1, then is the axis that is doing most of the motion?*/ 
    p1 = 2 * dy - dx; 
    p2 = 2 * dz - dx;    

    while (x1 != x2) 
    {      
      x1 += xs;  //xtoggle      
      holder = motion_buffer[y].global_counter ++;
      motion_buffer[y].step_sequence[holder] = 0;
      if (p1 >= 0) 
      { 
        y1 += ys; //ytoggle 
      holder = motion_buffer[y].global_counter ++;
      motion_buffer[y].step_sequence[holder] = 1;
        p1 -= 2 * dx; 
      }
      if (p2 >= 0) 
      { 
        z1 += zs; //ztoggle 
      holder = motion_buffer[y].global_counter ++;
      motion_buffer[y].step_sequence[holder] = 2;
        p2 -= 2 * dx;  
      }
      p1 += 2 * dy; 
      p2 += 2 * dz;  
      
    } 
  }  
  // Driving the y axis
  else if (dy >= dx && dy >= dz) 
  {    
    p1 = 2 * dx - dy; 
    p2 = 2 * dz - dy;   
    while (y1 != y2) 
    {  
      y1 += ys;   //ytoggle
      holder = motion_buffer[y].global_counter ++;
      motion_buffer[y].step_sequence[holder] = 1;
      if (p1 >= 0) 
      { 
        x1 += xs;  //xtoggle 
      holder = motion_buffer[y].global_counter ++;
      motion_buffer[y].step_sequence[holder] = 0;
        p1 -= 2 * dy;  
      } 
      if (p2 >= 0) 
      { 
        z1 += zs;  //ztoggle
      holder = motion_buffer[y].global_counter ++;
      motion_buffer[y].step_sequence[holder] = 2;
        p2 -= 2 * dy;  
      } 
      p1 += 2 * dx; 
      p2 += 2 * dz;  

    } 
  }  
  // Driving the z axis
  else 
  {   
    p1 = 2 * dy - dz; 
    p2 = 2 * dx - dz;  
    while (z1 != z2) 
    {   
     z1 += zs;   //ztoggle
     holder = motion_buffer[y].global_counter ++;
     motion_buffer[y].step_sequence[holder] = 2;
     if (p1 >= 0)
     { 
       y1 += ys;  //ytoggle 
       holder = motion_buffer[y].global_counter ++;
       motion_buffer[y].step_sequence[holder] = 1;
       p1 -= 2 * dz; 
     }
     if (p2 >= 0) 
     {  
       x1 += xs;  //xtoggle
       holder = motion_buffer[y].global_counter ++;
       motion_buffer[y].step_sequence[holder] = 0;
       p2 -= 2 * dz; 
     }
     p1 += 2 * dy;
     p2 += 2 * dx; 
     
    } 
  }  
   delay_ms(100);  
}

        while (1){         
        } //end of while (1)
}//end of main

//****************************************** Kinematics code 
//void update_motion_buffer(double* target){ 
//    int i;
//    uint32_t target_steps[N_Axis]; 
//    motion_block_t *block = &motion_buffer[motion_buffer_head];   
//    block -> step_count = 0;  
//    block -> millimeters = 0; 
//    for(i=0;i<N_Axis;i++){
//        if (i == 3 || i == 4){ 
//            target_steps[i] = target[i];  
//            //target_steps[i] = lround(target[i]*steps_per_radian);  
//            block -> steps[i] = (target_steps[i] - pos.position[i]); 
//            block -> step_count = max(block->step_count,block->steps[i]); 
//            block -> radians += (target_steps[i] - pos.position[i]); 
//        }else{
//            target_steps[i] = target[i]*steps_per_mm; 
//           // target_steps[i] = lround(target[i]*steps_per_mm) ; 
//            block -> steps[i] = abs((target_steps[i] - pos.position[i])); 
//            block -> step_count = max(block->step_count,block->steps[i]);  
//        }
//    }
////    block -> millimeters = sqrt(block->millimeters); 
//   motion_buffer_head ++;  
//}
//****************************************** Kinematics code 

//int max_num_step (int x_counter, int y_counter, int z_counter){   
//  int max = x_counter;
//  int arr[] = {x_counter, y_counter, z_counter}; 
//  for (int i = 0; i < 3; i ++){ 
//    if (arr[i] > max){ 
//      max = arr[i];
//    }
//  }
//  return max;
//} 


