//timer_fresh
#include "atmel_start.h"
#include <hal_gpio.h>
#include <hal_delay.h>  
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


//****************************************** Kinematics code 
#define driver_res 1 

#define N_Axis 5
#define steps_per_mm 800
#define steps_per_radian 127
#define motion_buffer_size 256
#define seq_length 300
#define total_num_blocks 6

typedef struct{
    uint32_t steps[N_Axis];   
    uint32_t step_sequence[seq_length]; 
    uint32_t global_counter;
    uint32_t direction[N_Axis];   
}motion_block_t; 


volatile static motion_block_t motion_buffer[motion_buffer_size];  

volatile int motion_buffer_head; 

static struct timer_task task0, task1, task2; 

volatile int x_counter = 0; 
volatile int x_stepper = 0; 

volatile int y_counter = 0; 
volatile int y_stepper = 0; 

volatile int z_counter = 0; 
volatile int z_stepper = 0; 


volatile int x_dir = 0;
volatile int y_dir = 0;
volatile int z_dir = 0;


volatile int x_enable = 0;
volatile int y_enable = 0;
volatile int z_enable = 0;  

volatile int x_dir_enable = 0;
volatile int y_dir_enable = 0;
volatile int z_dir_enable = 0;

volatile int block_release = 0;
volatile int seq_holder = 0;
volatile int seq_counter = 0; 

volatile int j = 0;

volatile int w = 0; 
volatile int counter = 0;


volatile int input_stream[total_num_blocks][3] = 
      { 
       {1,0,0}, 
       {0,1,0},
       {0,0,1},
       {0,0,1},
       {0,1,0},
       {1,1,1},
      };    

volatile int glob_counter[total_num_blocks];

volatile int sequence[total_num_blocks][seq_length] = 
      { 
       {0}, 
       {0},
       {0},
       {0},
       {0},
       {0},
      };    




static void task0_cb(const struct timer_task *const timer_task) 
{    
      if (sequence[w][j] == 0){ 
        gpio_toggle_pin_level(xstep);  
        j++;
      } 
      if (sequence[w][j] == 1){ 
        gpio_toggle_pin_level(ystep);  
        j++;
      }
      if (sequence[w][j] == 2){ 
        gpio_toggle_pin_level(zstep);  
        j++;
      }
} 

int main(void)
{  

	atmel_start_init(); 

      task0.interval = 100; 
      task0.cb = task0_cb; 
      task0.mode = TIMER_TASK_REPEAT; 
      timer_add_task(&TIMER_0, &task0);     
      timer_start(&TIMER_0);      





 for (int y = 0; y < total_num_blocks; y ++) {     

   int holder = 0;

   x_counter = (input_stream[y][0])*100; 
   y_counter = (input_stream[y][1])*100;   
   z_counter = (input_stream[y][2])*100;      

  int dx, dy, dz, xs, ys, zs, p1, p2;  
  int x1 = 0; 
  int y1 = 0; 
  int z1 = 0; 
  int x2 = x_counter;
  int y2 = y_counter;
  int z2 = z_counter; 

  dx =  abs(x2-x1);
  dy =  abs(y2-y1);
  dz =  abs(z2-z1);  

  glob_counter[y]= 0; 
  sequence[y][glob_counter[y]] = 0;

  if  (x2 > x1){  
    xs = 1;
  }else{ 
    xs = -1;
  }
  if  (y2 > y1){  
    ys = 1;
  }else{ 
    ys = -1;
  }
  if  (z2 > z1){  
    zs = 1;
  }else{ 
    zs = -1;
  }      

  if (dx >= dy && dx >= dz) 
  { 
    p1 = 2 * dy - dx; 
    p2 = 2 * dz - dx;    

    while (x1 != x2) 
    {     
      
      x1 += xs;  //xtoggle         
      sequence[y][glob_counter[y]] = 0;
      glob_counter[y]++;  
      if (p1 >= 0) 
      { 
        y1 += ys; //ytoggle 
        sequence[y][glob_counter[y]] = 1;
        glob_counter[y]++;  
        p1 -= 2 * dx;
      }
      if (p2 >= 0) 
      { 
        z1 += zs; //ztoggle 
        sequence[y][glob_counter[y]] = 2;
        glob_counter[y]++;  
        p2 -= 2 * dx; 
      }
      p1 += 2 * dy; 
      p2 += 2 * dz;  
      
    } 
  }  
  // Driving the y axis
  else if (dy >= dx && dy >= dz) 
  {    
    p1 = 2 * dx - dy; 
    p2 = 2 * dz - dy;   
    while (y1 != y2) 
    {  
      y1 += ys;   //ytoggle
      sequence[y][glob_counter[y]] = 1;
      glob_counter[y]++;  
      if (p1 >= 0) 
      { 
        x1 += xs;  //xtoggle 
        p1 -= 2 * dy;   
        sequence[y][glob_counter[y]] = 0;
        glob_counter[y]++;  
      } 
      if (p2 >= 0) 
      { 
        z1 += zs;  //ztoggle
        p2 -= 2 * dy;  
        sequence[y][glob_counter[y]] = 2;
        glob_counter[y]++;  
      } 
      p1 += 2 * dx; 
      p2 += 2 * dz;  

    } 
  }  
  // Driving the z axis
  else 
  {   
    p1 = 2 * dy - dz; 
    p2 = 2 * dx - dz;  
    while (z1 != z2) 
    {   
     z1 += zs;   //ztoggle
     sequence[y][glob_counter[y]] = 2;
     glob_counter[y]++;  
     if (p1 >= 0) 
     { 
       y1 += ys;  //ytoggle 
       sequence[y][glob_counter[y]] = 1;
       glob_counter[y]++;  
       p1 -= 2 * dz; 
     }
     if (p2 >= 0) 
     {  
       x1 += xs;  //xtoggle
       sequence[y][glob_counter[y]] = 0;
       glob_counter[y]++;  
       p2 -= 2 * dz; 
     }
     p1 += 2 * dy;
     p2 += 2 * dx; 
    } 
  } 
        }   

  for (int w = 0; w < total_num_blocks; w++){  
    for (j = 0; j < glob_counter[w];){ 
    }
    delay_ms(1000);
  }

        while (1){         

          
        }  //end of while (1) 
}//end of main

